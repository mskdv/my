package com.kims.achala.kims.service;

import java.util.List;

import com.kims.achala.kims.domain.FiltersEnum;
import com.kims.achala.kims.domain.MriAppointmentGivenEntity;
import com.kims.achala.kims.model.FilterDataVo;
import com.kims.achala.kims.model.MriAppointmentGivenVo;
import com.kims.achala.kims.model.ResponseVO;

 

public interface MriAppointmentGivenService {
	public List<FilterDataVo> getData(FiltersEnum filter);
	public MriAppointmentGivenEntity addData(MriAppointmentGivenEntity appointmentGivenEntity);
	//public MriAppointmentGivenVo getValuesByType(FiltersEnum type);
	public List<MriAppointmentGivenEntity> getAllData(MriAppointmentGivenEntity entity);
	List<MriAppointmentGivenEntity> getAlData();
}
