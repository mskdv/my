package com.kims.achala.kims.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.kims.achala.kims.domain.FiltersEnum;
import com.kims.achala.kims.domain.MriAppointmentGivenEntity;
import com.kims.achala.kims.model.FilterDataVo;
import com.kims.achala.kims.model.MriAppointmentGivenVo;
import com.kims.achala.kims.service.MriAppointmentGivenService;

@RestController
@RequestMapping("/api")
public class MriAppointmentGivenController {
	@Autowired
	private MriAppointmentGivenService mriAppointmentGivenService;
	@GetMapping("/filterdata/{filter}")
	public List<FilterDataVo> getData(@PathVariable FiltersEnum filter) {
		return mriAppointmentGivenService.getData(filter);
		
	}
	@GetMapping("/getAllData")
	public List<MriAppointmentGivenEntity> getAllData(MriAppointmentGivenEntity entity) 	{
		return mriAppointmentGivenService.getAllData(entity);

	}

	/*
	 * @GetMapping("/getValuesByType") public MriAppointmentGivenVo
	 * getValuesByType(@RequestParam("type") FiltersEnum type){ return
	 * mriAppointmentGivenService.getValuesByType(type); }
	 */
	@PostMapping("/createData")
	public MriAppointmentGivenEntity addData(MriAppointmentGivenEntity appointmentGivenEntity) {
		return mriAppointmentGivenService.addData(appointmentGivenEntity);
		
	}
	@GetMapping("/getAlData")
	public List<MriAppointmentGivenEntity> getAlData()
	{
		return mriAppointmentGivenService.getAlData();
	}
	
	 
}
