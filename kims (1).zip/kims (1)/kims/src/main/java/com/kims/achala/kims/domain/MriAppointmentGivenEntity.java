package com.kims.achala.kims.domain;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
@Data
@Setter
@Getter
@Entity

@Table(name="qms_tat_report")
public class MriAppointmentGivenEntity 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	@Enumerated(EnumType.STRING)
	private FiltersEnum filtersEnum;
	private Timestamp created_at;
	private String name;
	private String umr;
	
	private Date date;
	@Column(name="casetype")
	private String caseType;
	
	@Column(name="billnumber")
	private String billNumber;
	@Column(name="has_appointment") 
	private String hasAppointment;
	@Column(name="appointment_date")							
	private Date appointmentDate ;
	private String gender;
	private String age;
	@Column(name="phonenumber")
	private String phoneNumber;
	@Column(name="billing_time")
	private Timestamp billingTime;
	private String emergency ;
	@Column(name="arrivaltime") 
	private Timestamp arrivalTime ;
	@Column(name="checkin_time")	
	private Timestamp checkInTime;
	@Column(name="checkout_time")
	private Timestamp checkOutTime;
	private String unitid;
	private String departmentid ;
	private String servicegroupidid;
	private String unitname;
	private String departmentname;
	private String service_group_name;
	private String service_name;
	private String location;
	private Timestamp report_dispatch_time;
	private Timestamp report_approved_time;
	private Timestamp report_prepared_time;
	private String investigatetat;
	private String proceduraltat;
	private String resultentrytat;
	private String reportingtat;
	private String waitingtat;
	private String doctor_name;
	private String room_number;
	private String delay_reason;
	private String delay_reason_id;
	private Timestamp initial_appointment_date;
	private Timestamp approached_time;
	private String newtat2;
	private String newtat3;
	private String booked_reason;
	private String reschedule_reason;
	private String appointment_request_time;
	private String reschedule_status;
	private String patient_status;
	private String appointment_status;
	private String appointment_cancel_status;
	private String appointment_cancel_reason;
	private String  nurse_station_number;
	private Timestamp visiting_date;
	private String appointment_id;
	private String total_skip_count;
	private String latest_skip_reason;
	private String latest_room_change_reason;
	private Timestamp data_fetched_time;
	private String service_time;
	private String appointment_room_name;
	private String app_booked_by;
	private String payer_type;
	private String billed_service_id;
	private String bill_done_by;
	private String bill_cancel_status;
	private String bill_cancel_date;
	

	
	
	
	
}
