package com.kims.achala.kims.domain;

public enum FiltersEnum {
	UNIT_NAME,
	SERVICE_GROUP,
	SERVICE_NAME,
	INVESTIGATION_ROOM_NO,
	PRAYER_TYPE,
}
