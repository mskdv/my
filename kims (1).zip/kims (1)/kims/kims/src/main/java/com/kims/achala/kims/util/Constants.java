package com.kims.achala.kims.util;

public class Constants {

	 

		public static final String CHANGE_PWD_NOT_MATCHING = "Your current password is wrong.";
		public static final String CHANGE_PWD_SUCCESS = "Password changed successfully.";
		
		
		public static final String VALID_SUCCESS = "Valid success";
		
		public static final String STUD_UNIQUE_ENROLLMENT = "Enrollment number already tagged to another student.";
		public static final String STUD_UNIQUE_ADMISSION = "Admission No  already tagged to another student.";
		public static final String STUD_UNIQUE_EMAIL = "Email already tagged to another student.";
		public static final String STUD_UNIQUE_PHONE = "Phone number already tagged to another student.";
		public static final String STUD_UNIQUE_FATHER_EMAIL = "Father email should be unique.";
		public static final String STUD_UNIQUE_FATHER_PHONE = "Father phone number should be unique";
		public static final String STUD_UNIQUE_MOTHER_EMAIL = "Mother email should be unique";
		public static final String STUD_UNIQUE_MOTHER_PHONE = "Mother phone number should be unique";
		
		//STAFF
		public static final String STAFF_UNIQUE_PHONE = "Phone number should be unique";
		public static final String STAFF_UNIQUE_EMERGENCY_PHONE = "Emergency phone number should be unique";
		public static final String STAFF_UNIQUE_EMAIL = "Email should be unique";
		public static final String STAFF_ALT_UNIQUE_EMAIL = "Alternate Email should be unique";
		public static final String STAFF_UNIQUE_ERP_CODE = "ERP code should be unique";
		public static final String UPDATE_STAFF_SUCCESS = "Staff details updated successfully";
		public static final String ADD_STAFF_SUCCESS = "Staff details saved successfully";
		public static final String ADD_STAFF_FAILED = "Saving/updating staff details failed";
		public static final String STAFF_NOT_PRESENT = "Staff record not available.";
		public static final String STAFF_STATUS_UPDATE_SUCCESS = "Staff status updated successfully.";
		public static final String STAFF_STATUS_UPDATE_FAILED = "Staff status update failed.";
		
		
		public static final String INVALID_CLASS = "Invalid class";
		public static final String INVALID_DEPARTMENT = "Invalid department";
		public static final String UPDATE_STUDENT_SUCCESS = "Student details updated successfully";
		public static final String ADD_STUDENT_SUCCESS = "Student details saved successfully";
		public static final String ADD_STUDENT_FAILED = "Saving/updating student details failed";
		public static final String INVALID_EXCEL_FILE_FORMAT = "Invalid format of the file ";
		public static final String FILE_UPLOAD_SUCCESS = "Uploaded the file successfully: ";
		public static final String FILE_UPLOAD_FAILED = "Could not upload the file: ";
		public static final String INVALID_EXCEL_FILE_UPLOAD = "Please upload an excel file!";
		public static final String FILE_SIZE_EXCEPTION = "File too large!";
		public static final String UPDATE_SUBJECT_SUCCESS = "Subject details updated successfully";
		public static final String ADD_SUBJECT_SUCCESS = "Subject details saved successfully";
		public static final String ADD_SUBJECT_FAILED = "Saving/updating subject details failed";
		public static final String UPDATE_DEPARTMENT_SUCCESS = "Department details updated successfully";
		public static final String ADD_DEPARTMENT_SUCCESS = "Department details saved successfully";
		public static final String ADD_DEPARTMENT_FAILED = "Saving/updating department details failed";
		
		
		
		public static final String UPDATE_LESSONPLAN_SUCCESS = "Lessonplan details updated successfully";
		public static final String ADD_LESSONPLAN_SUCCESS = "Lessonplan details saved successfully";
		public static final String ADD_LESSONPLAN_FAILED = "Saving/updating lessonplan details failed";
		public static final String INVALID_CLASS_OR_SUBJECT = "Invalid class/subject";
		
		public static final String USER_ACCESS_EXIST = "User access setting already available with this configuration.";
		public static final String USER_ACCESS_ADD_SUCCESS = "User access settings added successfully.";
		public static final String USER_ACCESS_ADD_FAILED = "User access settings update failed.";
		public static final String USER_ACCESS_UPDATE_SUCCESS = "User access settings updated successfully.";

		public static final String INVALID_DETAILS = "Invalid Details";

		public static final String ADD_CLASS_OBSERVATION_SUCCESS = "Class Observation details saved successfully";
		public static final String UPDATE_CLASS_OBSERVATION_SUCCESS = "Class Observation details updated successfully";
		public static final String ADD_CLASS_OBSERVATION_FAILED = "Saving/updating Class Observation details failed";

		public static final String ADD_TEACHERS_ATTENDANCE_SUCCESS = "Teacher Attendance details saved successfully";
		public static final String UPDATE_TEACHERS_ATTENDANCE_SUCCESS = "Teacher Attendance details updated successfully";
		public static final String ADD_TEACHERS_ATTENDANCE_FAILED = "Saving/updating Teacher Attendance details failed";

		public static final String ADD_MOM_SUCCESS =  "Minutes of meeting details saved successfully";
		public static final String UPDATE_MOM_SUCCESS = "Minutes of meeting details updated successfully";
		public static final String ADD_MOM_FAILED = "Saving/updating Minutes of meeting details failed";

		public static final String ADD_COMPETITIONS_ACHIEVE_SUCCESS = "Competitions and achievements details saved successfully";
		public static final String UPDATE_COMPETITIONS_ACHIEVE_SUCCESS = "Competitions and achievements details updated successfully";
		public static final String ADD_COMPETITIONS_ACHIEVE_FAILED = "Saving/updating Competitions and achievements details failed";
		
		public static final String ADD_PARENT_COMMUNICATION_SUCCESS =  "Parent school communication details saved successfully";
		public static final String UPDATE_PARENT_COMMUNICATION_SUCCESS = "Parent school communication details updated successfully";
		public static final String ADD_PARENT_COMMUNICATION_FAILED = "Saving/updating parent school communication details failed";
		
		public static final String ADD_AWARDS_AND_RECOGNITION_SUCCESS =  "Awards And Recognition details saved successfully";
		public static final String UPDATE_AWARDS_AND_RECOGNITION_SUCCESS = "Awards And Recognition details updated successfully";
		public static final String ADD_AWARDS_AND_RECOGNITION_FAILED = "Saving/updating awards And Recognition details failed";

		public static final String ADD_STAFF_TRAINING_ACHIEVEMENTS_SUCCESS =  "Staff training Achievements details saved successfully";
		public static final String UPDATE_STAFF_TRAINING_ACHIEVEMENTS_SUCCESS = "Staff training Achievements details updated successfully";
		public static final String ADD_STAFF_TRAINING_ACHIEVEMENTS_FAILED = "Saving/updating staff training Achievements details failed";

		public static final String ADD_EVALUATION_CORRECTIONS_SUCCESS = "Evaluation corrections details saved successfully";
		public static final String UPDATE_EVALUATION_CORRECTIONS_SUCCESS = "Evaluation corrections details updated successfully";
		public static final String ADD_EVALUATION_CORRECTIONS_FAILED = "Saving/updating Evaluation corrections details failed";

		public static final String ADD_PARENT_TEACHER_STUDENT_ENGAGEMENT_SUCCESS ="Parent teacher student engagement details saved successfully";
		public static final String UPDATE_PARENT_TEACHER_STUDENT_ENGAGEMENT_SUCCESS = "Parent teacher student engagement details updated successfully";
		public static final String ADD_PARENT_TEACHER_STUDENT_ENGAGEMENT_FAILED = "Saving/updating parent teacher student engagement details failed";
		
		public static final String UPDATE_PMIDATA_SUCCESS = "PMI Data Details updated successfully";
		public static final String ADD_PMIDATA_SUCCESS = "PMI Data Details saved successfully";
		public static final String ADD_PMIDATA_FAILED = "Saving/updating PMI Data Details failed";
		
		public static final String ADD_PMI_GUIDELINES_SUCCESS = "PMI guidelines saved successfully";
		public static final String UPDATE_PMI_GUIDELINES_SUCCESS =  "PMI guidelines updated successfully";
		public static final String ADD_PMI_GUIDELINES_FAILED = "Saving/updating PMI guidelines failed";
		
		public static final String ADD_ACTIVITY_PLANNER_SUCCESS = "Activity planner saved successfully";
		public static final String UPDATE_ACTIVITY_PLANNER_SUCCESS = "Activity planner updated successfully";
		public static final String ADD_ACTIVITY_PLANNER_FAILED = "Saving activity planner failed";
		public static final String UPDATE_ACTIVITY_PLANNER_FAILED = "Updating activity planner failed";
		
		
		public static final String ADD_ACTIVITY_PLANNER_COMMON_DATA_SUCCESS = "Activity planner common data values saved successfully";
		public static final String ADD_ACTIVITY_PLANNER_COMMON_DATA_FAILED = "Saving Activity planner common data values failed";
		
		public static final String ADD_SUB_ACTIVITY_PLANNER_SUCCESS = "Sub activity planner saved successfully";
		public static final String ADD_SUB_ACTIVITY_PLANNER_FAILED ="Saving sub activity planner failed";
		public static final String UPDATE_SUB_ACTIVITY_PLANNER_SUCCESS = "Sub activity planner status updated successfully";
		public static final String UPDATE_SUB_ACTIVITY_PLANNER_FAILED = "Updating sub activity planner status failed";

	

}
