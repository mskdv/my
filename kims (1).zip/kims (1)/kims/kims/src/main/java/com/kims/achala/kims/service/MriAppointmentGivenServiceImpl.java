package com.kims.achala.kims.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kims.achala.kims.domain.FiltersEnum;
import com.kims.achala.kims.domain.MriAppointmentGivenEntity;
import com.kims.achala.kims.model.FilterDataVo;
import com.kims.achala.kims.model.MriAppointmentGivenVo;
import com.kims.achala.kims.model.ResponseVO;
import com.kims.achala.kims.repository.MriAppointmentGivenRepo;

@Service
public class MriAppointmentGivenServiceImpl implements MriAppointmentGivenService {
	@Autowired
	private MriAppointmentGivenRepo mriAppointmentGivenRepo;
	
	@Override
	public List<FilterDataVo> getData(FiltersEnum filter) {
		 
		 
		if(filter==FiltersEnum.UNIT_NAME){
			return mriAppointmentGivenRepo.getFilterDetails();
			 
		}
		else if(filter==FiltersEnum.INVESTIGATION_ROOM_NO) 
		{
			return mriAppointmentGivenRepo.findByFiltersEnum(filter);
		} 
		else if(filter==FiltersEnum.PRAYER_TYPE) {
			return mriAppointmentGivenRepo.getFilterDetails();
		}

		else if(filter==FiltersEnum.SERVICE_GROUP){
			return mriAppointmentGivenRepo.getFilterDetails();
			//mriAppointmentGivenRepo.f

		} 		
		else if(filter==FiltersEnum.SERVICE_NAME){
			return mriAppointmentGivenRepo.getFilterDetails();
		}
		return null;
		/*
		 * else if(filter==FiltersEnum.SERVICE_NAME){ return
		 * mriAppointmentGivenRepo.findByFiltersEnum(filter); } return null;
		 */
	}

	@Override
	public List<MriAppointmentGivenEntity> getAllData(MriAppointmentGivenEntity entity) {
		return mriAppointmentGivenRepo.findAll();
		
	}
	
	@Override
	public MriAppointmentGivenEntity addData(MriAppointmentGivenEntity appointmentGivenEntity) {
		
		return mriAppointmentGivenRepo.save(appointmentGivenEntity);
	}

	
	/*
	 * @Override public MriAppointmentGivenVo getValuesByType(FiltersEnum type) {
	 * List<MriAppointmentGivenEntity> valueEntities =
	 * mriAppointmentGivenRepo.findByType(type); List<FiltersEnum> list =
	 * Arrays.asList(FiltersEnum.values());
	 * valueEntities.forEach(x->list.add(x.getFiltersEnum())); MriAppointmentGivenVo
	 * vo = new MriAppointmentGivenVo(); //vo.setFiltersEnum(list);; return vo; }
	 */
	

	 
	
}
