package com.kims.achala.kims.model;

public class ResponseVO {
	
	private String successResponse;

	private String failedResponse;

	public String getSuccessResponse() {
		return successResponse;
	}

	public void setSuccessResponse(String successResponse) {
		this.successResponse = successResponse;
	}

	public String getFailedResponse() {
		return failedResponse;
	}

	public void setFailedResponse(String failedResponse) {
		this.failedResponse = failedResponse;
	}

	public ResponseVO(String successResponse, String failedResponse) {
		this.successResponse = successResponse;
		this.failedResponse = failedResponse;
	}

}
