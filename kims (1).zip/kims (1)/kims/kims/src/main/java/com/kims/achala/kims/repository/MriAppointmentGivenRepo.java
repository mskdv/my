package com.kims.achala.kims.repository;

 

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.kims.achala.kims.domain.MriAppointmentGivenEntity;
import com.kims.achala.kims.model.FilterDataVo;

public interface MriAppointmentGivenRepo extends JpaRepository<MriAppointmentGivenEntity,Long> {

	public List<FilterDataVo> findByFiltersEnum(Enum filter);
	@Query(value="select DISTINCT t.filters_enum,'UNIT_NAME' AS filter from t_mri_appointment_given t ", nativeQuery=true)
    List<FilterDataVo> getFilterDetails();

	//public List<MriAppointmentGivenEntity> findByType(FiltersEnum type);

}
