package com.kims.achala.kims.model;

public class FilterDataVo {
	private String filter;
	private String coulmnName;
	public String getFilter() {
		return filter;
	}
	public void setFilter(String filter) {
		this.filter = filter;
	}
	public String getCoulmnName() {
		return coulmnName;
	}
	public void setCoulmnName(String coulmnName) {
		this.coulmnName = coulmnName;
	}
	

}
