package com.kims.achala.kims;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KimsApplicationTests {

	@Test
	void contextLoads() {
	}

}
