package com.kims.achala.kims.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.achala.lms.activityplanner.domain.ActivityPlannerCommonDataEntity;
import com.achala.lms.activityplanner.domain.ActivityPlannerEnum;
import com.achala.lms.activityplanner.model.ActivityPlannerCommonDataVO;
import com.kims.achala.kims.domain.MriAppointmentGivenVo;
import com.kims.achala.kims.domain.ResponseVO;
import com.kims.achala.kims.model.FiltersEnum;
import com.kims.achala.kims.model.MriAppointmentGivenEntity;
import com.kims.achala.kims.repository.MriAppointmentGivenRepo;

@Service
public class MriAppointmentGivenServiceImpl implements MriAppointmentGivenService {
	@Autowired
	private MriAppointmentGivenRepo mriAppointmentGivenRepo;
	
	@Override
	public String getData(Enum filter) {
		MriAppointmentGivenEntity entity= new MriAppointmentGivenEntity();
		entity.getFiltersEnum();
		if(filter==FiltersEnum.UNIT_NAME){
			return mriAppointmentGivenRepo.findByFiltersEnum(filter);
		} else {
			entity.getFiltersEnum();
			if(filter==FiltersEnum.INVESTIGATION_ROOM_NO) 
			{
				return mriAppointmentGivenRepo.findByFiltersEnum(filter);
			} else {
				entity.getFiltersEnum();
				if(filter==FiltersEnum.PRAYER_TYPE) {
					return mriAppointmentGivenRepo.findByFiltersEnum(filter);
				} else {
					entity.getFiltersEnum();
					if(filter==FiltersEnum.SERVICE_GROUP){
						return mriAppointmentGivenRepo.findByFiltersEnum(filter);
					} else {
						entity.getFiltersEnum();
						if(filter==FiltersEnum.SERVICE_NAME){
							return mriAppointmentGivenRepo.findByFiltersEnum(filter);
						}
					}
				}
			}
		}
		return null;
		
		
	}

	@Override
	public List<MriAppointmentGivenEntity> getAllData(MriAppointmentGivenEntity entity) {
		return mriAppointmentGivenRepo.findAll();
		
	}
	
	@Override
	public MriAppointmentGivenEntity addData(MriAppointmentGivenEntity appointmentGivenEntity) {
		
		return mriAppointmentGivenRepo.save(appointmentGivenEntity);
	}

	
	@Override
	public MriAppointmentGivenVo getValuesByType(FiltersEnum type) {
		List<MriAppointmentGivenEntity> valueEntities = mriAppointmentGivenRepo.findByType(type);
		List<FiltersEnum> list = Arrays.asList(FiltersEnum.values());		
		valueEntities.forEach(x->list.add(x.getFiltersEnum()));
		MriAppointmentGivenVo vo = new MriAppointmentGivenVo(); 
		vo.setFiltersEnum(list);;
	}
	

	 
	
}
