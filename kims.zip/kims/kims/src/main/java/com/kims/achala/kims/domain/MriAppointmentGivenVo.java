package com.kims.achala.kims.domain;

import java.util.List;

import com.kims.achala.kims.model.FiltersEnum;

public class MriAppointmentGivenVo {
	private FiltersEnum filtersEnum;
	private long id;
	public FiltersEnum getFiltersEnum() {
		return filtersEnum;
	}
	public void setFiltersEnum(FiltersEnum list) {
		this.filtersEnum = list;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	
}
