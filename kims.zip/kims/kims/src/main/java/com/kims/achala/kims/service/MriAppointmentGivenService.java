package com.kims.achala.kims.service;

import java.util.List;

import com.kims.achala.kims.domain.MriAppointmentGivenVo;
import com.kims.achala.kims.domain.ResponseVO;
import com.kims.achala.kims.model.FiltersEnum;
import com.kims.achala.kims.model.MriAppointmentGivenEntity;

 

public interface MriAppointmentGivenService {
	public String getData(Enum filter);
	public MriAppointmentGivenEntity addData(MriAppointmentGivenEntity appointmentGivenEntity);
	public MriAppointmentGivenVo getValuesByType(FiltersEnum type);
	public List<MriAppointmentGivenEntity> getAllData(MriAppointmentGivenEntity entity);
	
}
