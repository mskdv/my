package com.kims.achala.kims.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kims.achala.kims.model.FiltersEnum;
import com.kims.achala.kims.model.MriAppointmentGivenEntity;

public interface MriAppointmentGivenRepo extends JpaRepository<MriAppointmentGivenEntity,Long> {

	public String findByFiltersEnum(Enum filter);

	public List<MriAppointmentGivenEntity> findByType(FiltersEnum type);

}
