package com.kims.achala.kims.model;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="t_mri_appointment_given")
public class MriAppointmentGivenEntity 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	Long id;
	@Enumerated(EnumType.STRING)
	private FiltersEnum filtersEnum;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public FiltersEnum getFiltersEnum() {
		return filtersEnum;
	}
	public void setFiltersEnum(FiltersEnum filtersEnum) {
		this.filtersEnum = filtersEnum;
	}
	
	
	
}
